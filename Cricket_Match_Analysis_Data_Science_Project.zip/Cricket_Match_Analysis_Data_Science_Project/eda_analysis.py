"""
CRICKET MATCH PERFORMANCE ANALYSIS
STAGE 2: EXPLORATORY DATA ANALYSIS (EDA)
Dataset: IPL 2008-2024

Run:
    pip install pandas numpy matplotlib
    python eda_analysis.py

Expected input files in the same folder as this script:
    deliveries_2008-2024.csv
    matches_2008-2024.csv

Outputs are written to the EDA_Results folder.
"""

from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

BASE_DIR = Path(__file__).resolve().parent
OUTPUT_DIR = BASE_DIR / "EDA_Results"
OUTPUT_DIR.mkdir(exist_ok=True)

DELIVERIES_FILE = BASE_DIR / "deliveries_2008-2024.csv"
MATCHES_FILE = BASE_DIR / "matches_2008-2024.csv"


def load_and_standardize(path):
    """Load CSV and standardize headers and text fields."""
    df = pd.read_csv(path)
    df.columns = df.columns.astype(str).str.strip()

    for col in df.select_dtypes(include=["object"]).columns:
        df[col] = df[col].astype("string").str.strip()
        df[col] = df[col].replace({"NA": pd.NA, "": pd.NA})

    return df


# ---------------------------------------------------------
# 1. LOAD DATA
# ---------------------------------------------------------
deliveries = load_and_standardize(DELIVERIES_FILE)
matches = load_and_standardize(MATCHES_FILE)

# Convert relevant numeric columns safely.
delivery_numeric = [
    "match_id", "inning", "over", "ball", "batsman_runs",
    "extra_runs", "total_runs", "is_wicket"
]
for col in delivery_numeric:
    deliveries[col] = pd.to_numeric(deliveries[col], errors="coerce")

matches["id"] = pd.to_numeric(matches["id"], errors="coerce")
matches["season"] = matches["season"].astype("string")

# Treat missing extras_type as no extra.
deliveries["extras_type"] = deliveries["extras_type"].fillna("none").str.lower()

# ---------------------------------------------------------
# 2. DERIVE CRICKET-SPECIFIC FIELDS
# ---------------------------------------------------------
# Batter balls faced: wides are excluded; no-balls count as faced.
deliveries["is_batter_ball"] = (
    deliveries["extras_type"].ne("wides")
).astype(int)

# Bowler legal balls: wides and no-balls are not legal deliveries.
deliveries["is_legal_bowler_ball"] = (
    ~deliveries["extras_type"].isin(["wides", "noballs"])
).astype(int)

# Bowler-conceded runs: byes, legbyes and penalty runs are not charged
# to the bowler. Wides and no-balls are charged to the bowler.
deliveries["bowler_runs_conceded"] = deliveries["total_runs"]
deliveries.loc[
    deliveries["extras_type"].isin(["byes", "legbyes", "penalty"]),
    "bowler_runs_conceded"
] = (
    deliveries.loc[
        deliveries["extras_type"].isin(["byes", "legbyes", "penalty"]),
        "total_runs"
    ]
    - deliveries.loc[
        deliveries["extras_type"].isin(["byes", "legbyes", "penalty"]),
        "extra_runs"
    ]
)
# For byes/legbyes/penalty, subtract the relevant extras; the resulting
# amount is the batter's runs (normally zero). The expression above
# retains any batter runs if present.

# Bowler wickets: exclude dismissals not credited to the bowler.
non_bowler_dismissals = {
    "run out", "retired hurt", "retired out", "obstructing the field"
}
deliveries["bowler_wicket"] = (
    deliveries["is_wicket"].fillna(0).eq(1)
    & ~deliveries["dismissal_kind"].fillna("").str.lower().isin(non_bowler_dismissals)
).astype(int)

# Boundaries are based on batter runs, not total delivery runs.
deliveries["fours"] = deliveries["batsman_runs"].eq(4).astype(int)
deliveries["sixes"] = deliveries["batsman_runs"].eq(6).astype(int)
deliveries["boundary_runs"] = (
    deliveries["fours"] * 4 + deliveries["sixes"] * 6
)

# Exclude Super Over innings (inning > 2) from regular match analysis.
regular = deliveries[deliveries["inning"].isin([1, 2])].copy()

# ---------------------------------------------------------
# 3. DATASET OVERVIEW AND QUALITY SUMMARY
# ---------------------------------------------------------
overview = pd.DataFrame([
    ["Deliveries rows", len(deliveries)],
    ["Deliveries columns", len(deliveries.columns)],
    ["Matches rows", len(matches)],
    ["Matches columns", len(matches.columns)],
    ["Unique match IDs in deliveries", deliveries["match_id"].nunique()],
    ["Unique matches", matches["id"].nunique()],
    ["Unmatched delivery match IDs",
     len(set(deliveries["match_id"].dropna()) - set(matches["id"].dropna()))],
    ["Duplicate delivery rows", int(deliveries.duplicated().sum())],
    ["Duplicate match rows", int(matches.duplicated().sum())],
    ["Missing match winners", int(matches["winner"].isna().sum())],
], columns=["Metric", "Value"])
overview.to_csv(OUTPUT_DIR / "01_dataset_overview.csv", index=False)

missing = pd.DataFrame({
    "Column": list(deliveries.columns) + list(matches.columns),
    "Dataset": ["Deliveries"] * len(deliveries.columns) + ["Matches"] * len(matches.columns),
    "Missing_Count": [int(deliveries[c].isna().sum()) for c in deliveries.columns]
                     + [int(matches[c].isna().sum()) for c in matches.columns]
})
missing.to_csv(OUTPUT_DIR / "02_missing_values.csv", index=False)

# ---------------------------------------------------------
# 4. DESCRIPTIVE STATISTICS
# ---------------------------------------------------------
numeric_delivery = deliveries.select_dtypes(include=np.number)
numeric_match = matches.select_dtypes(include=np.number)

numeric_delivery.describe().T.to_csv(
    OUTPUT_DIR / "03_delivery_descriptive_statistics.csv"
)
numeric_match.describe().T.to_csv(
    OUTPUT_DIR / "04_match_descriptive_statistics.csv"
)

# ---------------------------------------------------------
# 5. BATTING AGGREGATION
# ---------------------------------------------------------
batting = regular.groupby("batter", dropna=True).agg(
    total_runs=("batsman_runs", "sum"),
    balls_faced=("is_batter_ball", "sum"),
    fours=("fours", "sum"),
    sixes=("sixes", "sum"),
    innings=("match_id", "nunique")
).reset_index()

batting["strike_rate"] = np.where(
    batting["balls_faced"] > 0,
    batting["total_runs"] / batting["balls_faced"] * 100,
    0
)
batting["boundary_runs"] = batting["fours"] * 4 + batting["sixes"] * 6
batting = batting.sort_values("total_runs", ascending=False)
batting.to_csv(OUTPUT_DIR / "05_batting_summary.csv", index=False)

# Minimum 50 balls faced for strike-rate leaderboard.
qualified_batting = batting[batting["balls_faced"] >= 50].copy()
qualified_batting.sort_values(
    "strike_rate", ascending=False
).head(10).to_csv(
    OUTPUT_DIR / "06_top10_strike_rate_min50_balls.csv", index=False
)

# ---------------------------------------------------------
# 6. BOWLING AGGREGATION
# ---------------------------------------------------------
bowling = regular.groupby("bowler", dropna=True).agg(
    runs_conceded=("bowler_runs_conceded", "sum"),
    legal_balls=("is_legal_bowler_ball", "sum"),
    wickets=("bowler_wicket", "sum"),
    matches=("match_id", "nunique")
).reset_index()

bowling["overs_bowled"] = bowling["legal_balls"] / 6
bowling["economy_rate"] = np.where(
    bowling["legal_balls"] > 0,
    bowling["runs_conceded"] * 6 / bowling["legal_balls"],
    0
)
bowling = bowling.sort_values("wickets", ascending=False)
bowling.to_csv(OUTPUT_DIR / "07_bowling_summary.csv", index=False)

# ---------------------------------------------------------
# 7. TEAM AND SEASON ANALYSIS
# ---------------------------------------------------------
valid_results = matches[matches["winner"].notna()].copy()
team_wins = (
    valid_results.groupby("winner")
    .size()
    .reset_index(name="matches_won")
    .sort_values("matches_won", ascending=False)
)
team_wins.to_csv(OUTPUT_DIR / "08_team_wins.csv", index=False)

season_summary = (
    regular.merge(
        matches[["id", "season"]],
        left_on="match_id",
        right_on="id",
        how="left"
    )
    .groupby("season")
    .agg(
        total_batter_runs=("batsman_runs", "sum"),
        total_delivery_runs=("total_runs", "sum"),
        delivery_records=("match_id", "size"),
        matches=("match_id", "nunique")
    )
    .reset_index()
    .sort_values("season")
)
season_summary.to_csv(OUTPUT_DIR / "09_season_summary.csv", index=False)

# ---------------------------------------------------------
# 8. MATCH INNINGS SUMMARY
# ---------------------------------------------------------
innings_summary = (
    regular.groupby(["match_id", "inning", "batting_team"])
    .agg(
        innings_runs=("total_runs", "sum"),
        wickets_lost=("is_wicket", "sum"),
        delivery_events=("match_id", "size")
    )
    .reset_index()
)
innings_summary.to_csv(OUTPUT_DIR / "10_innings_summary.csv", index=False)

# ---------------------------------------------------------
# 9. CORRELATION ANALYSIS
# ---------------------------------------------------------
corr_cols = ["total_runs", "balls_faced", "fours", "sixes",
             "strike_rate", "boundary_runs"]
batting[corr_cols].corr().to_csv(
    OUTPUT_DIR / "11_batting_correlation_matrix.csv"
)

# ---------------------------------------------------------
# 10. VISUALIZATIONS
# ---------------------------------------------------------
plt.figure(figsize=(10, 6))
top_runs = batting.head(10).sort_values("total_runs")
plt.barh(top_runs["batter"], top_runs["total_runs"])
plt.title("Top 10 IPL Batsmen by Total Runs (2008-2024)")
plt.xlabel("Total Runs")
plt.ylabel("Batter")
plt.tight_layout()
plt.savefig(OUTPUT_DIR / "12_top10_batsmen.png", dpi=160)
plt.close()

plt.figure(figsize=(10, 6))
top_wickets = bowling.head(10).sort_values("wickets")
plt.barh(top_wickets["bowler"], top_wickets["wickets"])
plt.title("Top 10 IPL Bowlers by Wickets (2008-2024)")
plt.xlabel("Wickets")
plt.ylabel("Bowler")
plt.tight_layout()
plt.savefig(OUTPUT_DIR / "13_top10_bowlers.png", dpi=160)
plt.close()

plt.figure(figsize=(10, 6))
top_teams = team_wins.head(10).sort_values("matches_won")
plt.barh(top_teams["winner"], top_teams["matches_won"])
plt.title("Top 10 Teams by Matches Won")
plt.xlabel("Matches Won")
plt.ylabel("Team")
plt.tight_layout()
plt.savefig(OUTPUT_DIR / "14_top10_teams_wins.png", dpi=160)
plt.close()

plt.figure(figsize=(10, 6))
plt.hist(batting["total_runs"], bins=30)
plt.title("Distribution of Player Total Runs")
plt.xlabel("Total Runs")
plt.ylabel("Number of Players")
plt.tight_layout()
plt.savefig(OUTPUT_DIR / "15_batting_runs_distribution.png", dpi=160)
plt.close()

plt.figure(figsize=(10, 6))
plt.scatter(batting["balls_faced"], batting["total_runs"], alpha=0.5)
plt.title("Relationship Between Balls Faced and Runs Scored")
plt.xlabel("Balls Faced")
plt.ylabel("Total Runs")
plt.tight_layout()
plt.savefig(OUTPUT_DIR / "16_runs_vs_balls_faced.png", dpi=160)
plt.close()

# ---------------------------------------------------------
# 11. PRINT KEY OUTPUTS
# ---------------------------------------------------------
print("\\nDATASET OVERVIEW")
print(overview.to_string(index=False))

print("\\nTOP 10 BATSMEN BY RUNS")
print(batting[["batter", "total_runs", "balls_faced",
               "strike_rate", "fours", "sixes"]].head(10).to_string(index=False))

print("\\nTOP 10 BOWLERS BY WICKETS")
print(bowling[["bowler", "wickets", "runs_conceded",
               "legal_balls", "economy_rate"]].head(10).to_string(index=False))

print("\\nTOP 10 TEAMS BY WINS")
print(team_wins.head(10).to_string(index=False))

print("\\nEDA COMPLETED. Results saved to:", OUTPUT_DIR)
