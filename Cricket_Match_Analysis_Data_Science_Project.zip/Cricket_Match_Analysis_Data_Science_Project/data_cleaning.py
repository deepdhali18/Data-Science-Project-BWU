import pandas as pd
import numpy as np
import os
from pathlib import Path


# ==========================================================
# PROJECT: CRICKET MATCH PERFORMANCE ANALYSIS
# MODULE: DATA CLEANING AND PREPROCESSING
# DATASET: IPL 2008-2024
# ==========================================================

import pandas as pd
import numpy as np
import os
from pathlib import Path

# ----------------------------------------------------------
# STEP 1: DEFINE DATASET PATHS
# ----------------------------------------------------------

DATA_FOLDER = Path("Cricket_Data_Science_Project")

DELIVERIES_FILE = DATA_FOLDER / "deliveries_2008-2024.csv"
MATCHES_FILE = DATA_FOLDER / "matches_2008-2024.csv"

# Create output directory
OUTPUT_FOLDER = DATA_FOLDER / "Cleaned_Data"
OUTPUT_FOLDER.mkdir(parents=True, exist_ok=True)


# ----------------------------------------------------------
# STEP 2: LOAD THE DATASETS
# ----------------------------------------------------------

deliveries = pd.read_csv(DELIVERIES_FILE)
matches = pd.read_csv(MATCHES_FILE)

print("Datasets loaded successfully!")

print("Deliveries Shape:", deliveries.shape)
print("Matches Shape:", matches.shape)


# ----------------------------------------------------------
# STEP 3: REMOVE EXTRA SPACES FROM COLUMN NAMES
# ----------------------------------------------------------

deliveries.columns = (
    deliveries.columns.astype(str).str.strip()
)

matches.columns = (
    matches.columns.astype(str).str.strip()
)

print("Column names standardized.")


# ----------------------------------------------------------
# STEP 4: CLEAN TEXT DATA
# ----------------------------------------------------------

def clean_text_data(df):

    df = df.copy()

    # Identify all text columns
    text_columns = df.select_dtypes(
        include=["object"]
    ).columns

    # Remove unnecessary leading/trailing spaces
    for column in text_columns:

        df[column] = (
            df[column]
            .astype("string")
            .str.strip()
        )

        # Standardize blank and NA text values
        df[column] = df[column].replace({
            "NA": pd.NA,
            "": pd.NA
        })

    return df


deliveries = clean_text_data(deliveries)
matches = clean_text_data(matches)

print("Text data cleaning completed.")


# ----------------------------------------------------------
# STEP 5: HANDLE MISSING VALUES
# ----------------------------------------------------------

# Missing extras_type indicates no recorded extra type.
if "extras_type" in deliveries.columns:

    deliveries["extras_type"] = (
        deliveries["extras_type"].fillna("none")
    )

print("Missing extras_type values handled.")


# ----------------------------------------------------------
# STEP 6: CHECK DUPLICATE RECORDS
# ----------------------------------------------------------

delivery_duplicates = deliveries.duplicated().sum()
match_duplicates = matches.duplicated().sum()

print("Duplicate delivery records:",
      delivery_duplicates)

print("Duplicate match records:",
      match_duplicates)

# No automatic deletion is performed.
# Duplicate-looking records must be investigated
# before deciding whether they are valid.


# ----------------------------------------------------------
# STEP 7: CHECK MISSING VALUES
# ----------------------------------------------------------

print("\nMissing values in Deliveries:")

print(deliveries.isnull().sum())

print("\nMissing values in Matches:")

print(matches.isnull().sum())


# ----------------------------------------------------------
# STEP 8: VALIDATE MATCH ID RELATIONSHIP
# ----------------------------------------------------------

delivery_match_ids = set(
    deliveries["match_id"].dropna().unique()
)

match_ids = set(
    matches["id"].dropna().unique()
)

unmatched_ids = delivery_match_ids - match_ids

print("\nUnmatched Match IDs:", len(unmatched_ids))


# ----------------------------------------------------------
# STEP 9: CHECK DATASET INFORMATION
# ----------------------------------------------------------

print("\nDeliveries Dataset Information:")

deliveries.info()

print("\nMatches Dataset Information:")

matches.info()


# ----------------------------------------------------------
# STEP 10: GENERATE DATA QUALITY REPORT
# ----------------------------------------------------------

quality_report = pd.DataFrame({

    "Check": [
        "Total Delivery Records",
        "Total Match Records",
        "Delivery Columns",
        "Match Columns",
        "Duplicate Delivery Records",
        "Duplicate Match Records",
        "Missing Fielder Values",
        "Missing Match Winners",
        "Missing City Values",
        "Unmatched Match IDs"
    ],

    "Result": [
        len(deliveries),
        len(matches),
        len(deliveries.columns),
        len(matches.columns),
        delivery_duplicates,
        match_duplicates,
        deliveries["fielder"].isnull().sum(),
        matches["winner"].isnull().sum(),
        matches["city"].isnull().sum(),
        len(unmatched_ids)
    ]

})


# ----------------------------------------------------------
# STEP 11: SAVE CLEANED DATASETS
# ----------------------------------------------------------

deliveries.to_csv(
    OUTPUT_FOLDER / "Clean_Deliveries.csv",
    index=False
)

matches.to_csv(
    OUTPUT_FOLDER / "Clean_Matches.csv",
    index=False
)

quality_report.to_csv(
    OUTPUT_FOLDER / "Data_Quality_Report.csv",
    index=False
)


# ----------------------------------------------------------
# STEP 12: FINAL OUTPUT
# ----------------------------------------------------------

print("\n====================================")
print("DATA CLEANING COMPLETED SUCCESSFULLY")
print("====================================")

print("Cleaned Deliveries:",
      deliveries.shape)

print("Cleaned Matches:",
      matches.shape)

print("Output Location:",
      OUTPUT_FOLDER)


How to execute this code
1. Install Python and Visual Studio Code or PyCharm.
2. Install Pandas and NumPy using the command provided above.
3. Create the project folder and put both original CSV files inside it.
4. Save the Python script as data_cleaning.py.
5. Run the script:
   
   bash     python data_cleaning.py
6. Check the Cleaned_Data folder for the three generated CSV files.
